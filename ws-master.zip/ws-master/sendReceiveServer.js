const WebSocket = require('ws');

const ws = new WebSocket.Server({ port: 8080 });

ws.on('connection', function connection(ws) {
    console.log('Start server');
    ws.on('message', function incoming(message) {
      console.log('received: %s', message);
    });
  
    ws.send('something');
  });

